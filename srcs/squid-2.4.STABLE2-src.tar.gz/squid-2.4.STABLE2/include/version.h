/*
 * $Id: version.h,v 1.131.2.4 2001/08/24 17:38:20 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"2.4.STABLE2"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 998676272
#endif
