#include <isc/types.h>

isc_result_t ldapdb_init(void);

void ldapdb_clear(void);

